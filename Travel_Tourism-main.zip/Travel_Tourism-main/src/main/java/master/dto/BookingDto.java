package master.dto;

public class BookingDto {
   private String tid;
   private String tname;
   private String hotel1;
   private String hotel2;
   private String hotel3;
   private String room;
   private String uname;
   private String stdt;
   private double price;
   private String status;
public String getTname() {
	return tname;
}
public void setTname(String tname) {
	this.tname = tname;
}
public String getTid() {
	return tid;
}
public void setTid(String tid) {
	this.tid = tid;
}
public String getHotel1() {
	return hotel1;
}
public void setHotel1(String hotel1) {
	this.hotel1 = hotel1;
}
public String getHotel2() {
	return hotel2;
}
public void setHotel2(String hotel2) {
	this.hotel2 = hotel2;
}
public String getHotel3() {
	return hotel3;
}
public void setHotel3(String hotel3) {
	this.hotel3 = hotel3;
}
public String getRoom() {
	return room;
}
public void setRoom(String room) {
	this.room = room;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getStdt() {
	return stdt;
}
public void setStdt(String stdt) {
	this.stdt = stdt;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
}
