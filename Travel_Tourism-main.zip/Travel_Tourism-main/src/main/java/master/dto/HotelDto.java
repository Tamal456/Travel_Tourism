package master.dto;

public class HotelDto {
   private String hid;
   private String hname;
   private String place;
   public String getHid() {
	   return hid;
   }
   public void setHid(String hid) {
	   this.hid = hid;
   }
   public String getHname() {
	   return hname;
   }
   public void setHname(String hname) {
	   this.hname = hname;
   }
   public String getPlace() {
	   return place;
   }
   public void setPlace(String tplace) {
	   this.place = tplace;
   }
   
   
}
