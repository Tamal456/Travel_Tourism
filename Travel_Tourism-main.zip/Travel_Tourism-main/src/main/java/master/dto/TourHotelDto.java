package master.dto;

public class TourHotelDto {
   private String tid;
   private String hid;
public String getTid() {
	return tid;
}
public void setTid(String tid) {
	this.tid = tid;
}
public String getHid() {
	return hid;
}
public void setHid(String hid) {
	this.hid = hid;
}
}
