package master.dto;

public class RegisterDto {
 private String uname;
 private String pass;
 private String nm;
 private String email;
 private String phno;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhno() {
	return phno;
}
public void setPhno(String phno) {
	this.phno = phno;
}
public String getNm() {
	return nm;
}
public void setNm(String nm) {
	this.nm = nm;
}
}
